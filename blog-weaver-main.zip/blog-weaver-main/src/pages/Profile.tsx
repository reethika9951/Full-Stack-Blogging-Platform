import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Layout } from "@/components/layout/Layout";
import { PostCard } from "@/components/posts/PostCard";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useBookmark } from "@/hooks/useInteractions";
import { usePosts } from "@/hooks/usePosts";

function BookmarkablePostCard(props: React.ComponentProps<typeof PostCard>) {
  const { isBookmarked, toggleBookmark } = useBookmark(props.id);
  return <PostCard {...props} isBookmarked={isBookmarked} onBookmark={toggleBookmark} />;
}

export default function Profile() {
  const { userId } = useParams();

  const { data: profile, isLoading: loadingProfile } = useQuery({
    queryKey: ["profile", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("user_id", userId!)
        .single();
      if (error) throw error;
      return data;
    },
  });

  const { data: posts, isLoading: loadingPosts } = usePosts({
    authorId: userId,
    status: "published",
  });

  const initials = profile?.display_name?.slice(0, 2).toUpperCase() ?? "?";

  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        {loadingProfile ? (
          <div className="flex items-center gap-4 mb-8">
            <Skeleton className="h-16 w-16 rounded-full" />
            <div className="space-y-2">
              <Skeleton className="h-6 w-40" />
              <Skeleton className="h-4 w-64" />
            </div>
          </div>
        ) : profile ? (
          <div className="flex items-start gap-4 mb-8 pb-8 border-b">
            <Avatar className="h-16 w-16">
              <AvatarImage src={profile.avatar_url ?? undefined} />
              <AvatarFallback className="text-lg bg-accent text-accent-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-2xl font-serif font-bold">{profile.display_name}</h1>
              {profile.bio && (
                <p className="text-muted-foreground mt-1 max-w-md">{profile.bio}</p>
              )}
              <p className="text-sm text-muted-foreground mt-2">
                {posts?.length ?? 0} {posts?.length === 1 ? "story" : "stories"} published
              </p>
            </div>
          </div>
        ) : (
          <p className="text-center text-muted-foreground py-16">Profile not found.</p>
        )}

        {loadingPosts ? (
          <div className="space-y-6">
            {[1, 2].map((i) => (
              <div key={i} className="flex gap-6 py-6 border-b">
                <div className="flex-1 space-y-3">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : posts && posts.length > 0 ? (
          posts.map((post) => (
            <BookmarkablePostCard
              key={post.id}
              id={post.id}
              title={post.title}
              excerpt={post.excerpt}
              coverImageUrl={post.cover_image_url}
              authorName={post.author?.display_name ?? "Anonymous"}
              authorAvatar={post.author?.avatar_url ?? null}
              authorId={post.author_id}
              publishedAt={post.published_at}
              readTimeMinutes={post.read_time_minutes}
              tags={post.tags}
              likeCount={post.like_count}
              commentCount={post.comment_count}
            />
          ))
        ) : (
          <p className="text-center text-muted-foreground py-8">No stories published yet.</p>
        )}
      </div>
    </Layout>
  );
}
