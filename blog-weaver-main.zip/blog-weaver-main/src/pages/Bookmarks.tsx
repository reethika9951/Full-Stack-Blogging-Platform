import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { PostCard } from "@/components/posts/PostCard";
import { useAuth } from "@/contexts/AuthContext";
import { useBookmarkedPosts, useBookmark } from "@/hooks/useInteractions";
import { Skeleton } from "@/components/ui/skeleton";
import { Bookmark } from "lucide-react";

function BookmarkablePostCard(props: React.ComponentProps<typeof PostCard>) {
  const { isBookmarked, toggleBookmark } = useBookmark(props.id);
  return <PostCard {...props} isBookmarked={isBookmarked} onBookmark={toggleBookmark} />;
}

export default function Bookmarks() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data: posts, isLoading } = useBookmarkedPosts();

  useEffect(() => {
    if (!user) navigate("/auth", { replace: true });
  }, [user, navigate]);

  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        <h1 className="text-3xl font-serif font-bold mb-8 flex items-center gap-3">
          <Bookmark className="h-7 w-7" />
          Your bookmarks
        </h1>

        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-6 py-6 border-b">
                <div className="flex-1 space-y-3">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : posts && posts.length > 0 ? (
          posts.map((post) => (
            <BookmarkablePostCard
              key={post.id}
              id={post.id}
              title={post.title}
              excerpt={post.excerpt}
              coverImageUrl={post.cover_image_url}
              authorName={post.author?.display_name ?? "Anonymous"}
              authorAvatar={post.author?.avatar_url ?? null}
              authorId={post.author_id}
              publishedAt={post.published_at}
              readTimeMinutes={post.read_time_minutes}
              tags={post.tags}
              likeCount={post.like_count}
              commentCount={post.comment_count}
            />
          ))
        ) : (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg">No bookmarks yet. Save stories to read later!</p>
          </div>
        )}
      </div>
    </Layout>
  );
}
