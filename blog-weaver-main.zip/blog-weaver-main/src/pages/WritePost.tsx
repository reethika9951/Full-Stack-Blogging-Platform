import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { RichTextEditor } from "@/components/editor/RichTextEditor";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { usePost } from "@/hooks/usePosts";
import { Loader2, X, Save, Send } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function WritePost() {
  const { postId } = useParams();
  const isEditing = !!postId;
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: existingPost, isLoading: loadingPost } = usePost(postId);

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);
  const [coverImageUrl, setCoverImageUrl] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (existingPost && isEditing) {
      setTitle(existingPost.title);
      setContent(existingPost.content);
      setExcerpt(existingPost.excerpt ?? "");
      setTags(existingPost.tags ?? []);
      setCoverImageUrl(existingPost.cover_image_url ?? "");
    }
  }, [existingPost, isEditing]);

  useEffect(() => {
    if (!user) navigate("/auth", { replace: true });
  }, [user, navigate]);

  const addTag = () => {
    const tag = tagInput.trim().toLowerCase();
    if (tag && !tags.includes(tag) && tags.length < 5) {
      setTags([...tags, tag]);
      setTagInput("");
    }
  };

  const removeTag = (tag: string) => {
    setTags(tags.filter((t) => t !== tag));
  };

  const handleTagKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      addTag();
    }
  };

  const savePost = async (status: "draft" | "published") => {
    if (!user) return;
    if (!title.trim()) {
      toast({ title: "Title required", description: "Please add a title.", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      const postData = {
        title: title.trim(),
        content,
        excerpt: excerpt.trim() || content.replace(/<[^>]*>/g, "").slice(0, 200),
        tags,
        cover_image_url: coverImageUrl || null,
        status,
        published_at: status === "published" ? new Date().toISOString() : null,
      };

      if (isEditing && postId) {
        const { error } = await supabase
          .from("posts")
          .update(postData)
          .eq("id", postId)
          .eq("author_id", user.id);
        if (error) throw error;
        toast({ title: status === "published" ? "Published!" : "Draft saved" });
      } else {
        const { data, error } = await supabase
          .from("posts")
          .insert({ ...postData, author_id: user.id })
          .select("id")
          .single();
        if (error) throw error;
        toast({ title: status === "published" ? "Published!" : "Draft saved" });
        if (data) navigate(`/post/${data.id}`, { replace: true });
      }

      queryClient.invalidateQueries({ queryKey: ["posts"] });
      queryClient.invalidateQueries({ queryKey: ["my-drafts"] });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (isEditing && loadingPost) {
    return (
      <Layout>
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="container max-w-3xl py-8 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-serif font-bold">
            {isEditing ? "Edit story" : "Write a story"}
          </h1>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => savePost("draft")}
              disabled={saving}
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Save className="h-4 w-4 mr-1" />}
              Save draft
            </Button>
            <Button
              size="sm"
              onClick={() => savePost("published")}
              disabled={saving}
              className="bg-accent text-accent-foreground hover:bg-accent/90"
            >
              {saving ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <Send className="h-4 w-4 mr-1" />}
              Publish
            </Button>
          </div>
        </div>

        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Title"
          className="text-3xl font-serif font-bold border-none shadow-none px-0 focus-visible:ring-0 placeholder:text-muted-foreground/40"
          maxLength={200}
        />

        <Input
          value={excerpt}
          onChange={(e) => setExcerpt(e.target.value)}
          placeholder="Write a brief excerpt (optional)"
          className="text-base border-none shadow-none px-0 focus-visible:ring-0 placeholder:text-muted-foreground/40"
          maxLength={300}
        />

        <Input
          value={coverImageUrl}
          onChange={(e) => setCoverImageUrl(e.target.value)}
          placeholder="Cover image URL (optional)"
          className="text-sm"
        />

        {coverImageUrl && (
          <img
            src={coverImageUrl}
            alt="Cover preview"
            className="w-full h-48 object-cover rounded-lg"
            onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
          />
        )}

        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={handleTagKeyDown}
              placeholder="Add tags (press Enter)"
              className="text-sm max-w-xs"
              maxLength={30}
            />
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="gap-1">
                  {tag}
                  <button onClick={() => removeTag(tag)}>
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          )}
        </div>

        <RichTextEditor content={content} onChange={setContent} />
      </div>
    </Layout>
  );
}
