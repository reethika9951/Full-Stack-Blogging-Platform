import { useParams, Link, useNavigate } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { usePost } from "@/hooks/usePosts";
import { useLike, useBookmark } from "@/hooks/useInteractions";
import { useAuth } from "@/contexts/AuthContext";
import { CommentSection } from "@/components/comments/CommentSection";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Heart, Bookmark, Edit, Trash2, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

export default function PostDetail() {
  const { postId } = useParams();
  const { data: post, isLoading } = usePost(postId);
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { isLiked, toggleLike } = useLike(postId ?? "");
  const { isBookmarked, toggleBookmark } = useBookmark(postId ?? "");

  const isAuthor = user?.id === post?.author_id;

  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete this post?")) return;
    const { error } = await supabase
      .from("posts")
      .delete()
      .eq("id", postId!)
      .eq("author_id", user!.id);

    if (error) {
      toast({ title: "Error", description: "Could not delete post.", variant: "destructive" });
    } else {
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      navigate("/", { replace: true });
      toast({ title: "Post deleted" });
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  if (!post) {
    return (
      <Layout>
        <div className="container max-w-3xl py-20 text-center">
          <h1 className="text-2xl font-serif font-bold mb-2">Post not found</h1>
          <p className="text-muted-foreground">This story may have been removed or doesn't exist.</p>
        </div>
      </Layout>
    );
  }

  const initials = post.author?.display_name?.slice(0, 2).toUpperCase() ?? "?";

  return (
    <Layout>
      <article className="container max-w-3xl py-8 animate-fade-in">
        {/* Cover image */}
        {post.cover_image_url && (
          <img
            src={post.cover_image_url}
            alt={post.title}
            className="w-full h-64 md:h-96 object-cover rounded-lg mb-8"
          />
        )}

        {/* Title */}
        <h1 className="text-4xl md:text-5xl font-serif font-bold leading-tight mb-6">
          {post.title}
        </h1>

        {/* Author info */}
        <div className="flex items-center justify-between mb-8">
          <Link
            to={`/profile/${post.author_id}`}
            className="flex items-center gap-3 hover:opacity-80 transition-opacity"
          >
            <Avatar className="h-10 w-10">
              <AvatarImage src={post.author?.avatar_url ?? undefined} />
              <AvatarFallback className="bg-accent text-accent-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{post.author?.display_name ?? "Anonymous"}</p>
              <p className="text-sm text-muted-foreground">
                {post.published_at
                  ? formatDistanceToNow(new Date(post.published_at), { addSuffix: true })
                  : "Draft"}
                {post.read_time_minutes && ` · ${post.read_time_minutes} min read`}
              </p>
            </div>
          </Link>

          {isAuthor && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={() => navigate(`/edit/${postId}`)}>
                <Edit className="h-4 w-4 mr-1" />
                Edit
              </Button>
              <Button variant="outline" size="sm" onClick={handleDelete} className="text-destructive">
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </div>
          )}
        </div>

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-8">
            {post.tags.map((tag) => (
              <Link key={tag} to={`/?tag=${encodeURIComponent(tag)}`}>
                <Badge variant="secondary">{tag}</Badge>
              </Link>
            ))}
          </div>
        )}

        {/* Content */}
        <div
          className="prose-article"
          dangerouslySetInnerHTML={{ __html: post.content }}
        />

        {/* Actions bar */}
        <Separator className="my-8" />
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleLike()}
            className={`gap-2 ${isLiked ? "text-destructive" : "text-muted-foreground"}`}
          >
            <Heart className={`h-5 w-5 ${isLiked ? "fill-destructive" : ""}`} />
            {post.like_count}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => toggleBookmark()}
            className={`gap-2 ${isBookmarked ? "text-accent" : "text-muted-foreground"}`}
          >
            <Bookmark className={`h-5 w-5 ${isBookmarked ? "fill-accent" : ""}`} />
            {isBookmarked ? "Saved" : "Save"}
          </Button>
        </div>

        {/* Comments */}
        <CommentSection postId={postId!} />
      </article>
    </Layout>
  );
}
