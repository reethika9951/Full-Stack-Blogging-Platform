import { useSearchParams } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { PostCard } from "@/components/posts/PostCard";
import { usePosts } from "@/hooks/usePosts";
import { useBookmark } from "@/hooks/useInteractions";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Clock, MessageCircle, X } from "lucide-react";

type SortOption = "newest" | "likes" | "comments";

function BookmarkablePostCard(props: React.ComponentProps<typeof PostCard>) {
  const { isBookmarked, toggleBookmark } = useBookmark(props.id);
  return <PostCard {...props} isBookmarked={isBookmarked} onBookmark={toggleBookmark} />;
}

export default function Index() {
  const [searchParams, setSearchParams] = useSearchParams();
  const search = searchParams.get("search") ?? undefined;
  const tag = searchParams.get("tag") ?? undefined;
  const sort = (searchParams.get("sort") as SortOption) ?? "newest";
  const { user } = useAuth();

  const { data: posts, isLoading } = usePosts({ search, tag, sort });

  const setSort = (s: SortOption) => {
    const params = new URLSearchParams(searchParams);
    params.set("sort", s);
    setSearchParams(params);
  };

  const clearFilters = () => {
    setSearchParams({});
  };

  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        {/* Hero section for non-logged-in users */}
        {!user && !search && !tag && (
          <section className="text-center py-12 mb-8 border-b">
            <h1 className="text-5xl md:text-6xl font-serif font-bold mb-4 tracking-tight">
              Stay curious.
            </h1>
            <p className="text-xl text-muted-foreground max-w-lg mx-auto leading-relaxed">
              Discover stories, thinking, and expertise from writers on any topic.
            </p>
          </section>
        )}

        {/* Active filters */}
        {(search || tag) && (
          <div className="flex items-center gap-2 mb-6">
            {search && (
              <div className="flex items-center gap-1">
                <span className="text-sm text-muted-foreground">Results for</span>
                <Badge variant="secondary" className="gap-1">
                  "{search}"
                  <button onClick={clearFilters}><X className="h-3 w-3" /></button>
                </Badge>
              </div>
            )}
            {tag && (
              <div className="flex items-center gap-1">
                <span className="text-sm text-muted-foreground">Tagged</span>
                <Badge variant="secondary" className="gap-1">
                  {tag}
                  <button onClick={clearFilters}><X className="h-3 w-3" /></button>
                </Badge>
              </div>
            )}
          </div>
        )}

        {/* Sort options */}
        <div className="flex items-center gap-1 mb-6 border-b pb-3">
          <Button
            variant={sort === "newest" ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setSort("newest")}
            className="gap-1.5 text-sm"
          >
            <Clock className="h-4 w-4" />
            Latest
          </Button>
          <Button
            variant={sort === "likes" ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setSort("likes")}
            className="gap-1.5 text-sm"
          >
            <TrendingUp className="h-4 w-4" />
            Most liked
          </Button>
          <Button
            variant={sort === "comments" ? "secondary" : "ghost"}
            size="sm"
            onClick={() => setSort("comments")}
            className="gap-1.5 text-sm"
          >
            <MessageCircle className="h-4 w-4" />
            Most discussed
          </Button>
        </div>

        {/* Post list */}
        {isLoading ? (
          <div className="space-y-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-6 py-6 border-b">
                <div className="flex-1 space-y-3">
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-6 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-48" />
                </div>
                <Skeleton className="hidden sm:block w-28 h-28 rounded" />
              </div>
            ))}
          </div>
        ) : posts && posts.length > 0 ? (
          posts.map((post) => (
            <BookmarkablePostCard
              key={post.id}
              id={post.id}
              title={post.title}
              excerpt={post.excerpt}
              coverImageUrl={post.cover_image_url}
              authorName={post.author?.display_name ?? "Anonymous"}
              authorAvatar={post.author?.avatar_url ?? null}
              authorId={post.author_id}
              publishedAt={post.published_at}
              readTimeMinutes={post.read_time_minutes}
              tags={post.tags}
              likeCount={post.like_count}
              commentCount={post.comment_count}
            />
          ))
        ) : (
          <div className="text-center py-16">
            <p className="text-muted-foreground text-lg">
              {search || tag ? "No posts found. Try a different search." : "No stories yet. Be the first to write one!"}
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
}
