import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";
import { MessageCircle, Reply, Trash2, Edit2, Loader2 } from "lucide-react";

interface CommentData {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  parent_id: string | null;
  profiles: {
    display_name: string;
    avatar_url: string | null;
    user_id: string;
  } | null;
  replies?: CommentData[];
}

function CommentItem({
  comment,
  postId,
  depth = 0,
}: {
  comment: CommentData;
  postId: string;
  depth?: number;
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [replying, setReplying] = useState(false);
  const [editing, setEditing] = useState(false);
  const [replyContent, setReplyContent] = useState("");
  const [editContent, setEditContent] = useState(comment.content);

  const isOwner = user?.id === comment.user_id;
  const initials = comment.profiles?.display_name?.slice(0, 2).toUpperCase() ?? "?";

  const addReply = useMutation({
    mutationFn: async () => {
      if (!user || !replyContent.trim()) return;
      const { error } = await supabase.from("comments").insert({
        post_id: postId,
        user_id: user.id,
        parent_id: comment.id,
        content: replyContent.trim(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setReplyContent("");
      setReplying(false);
      queryClient.invalidateQueries({ queryKey: ["comments", postId] });
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      queryClient.invalidateQueries({ queryKey: ["post", postId] });
    },
    onError: () => toast({ title: "Error", description: "Could not add reply.", variant: "destructive" }),
  });

  const updateComment = useMutation({
    mutationFn: async () => {
      if (!editContent.trim()) return;
      const { error } = await supabase
        .from("comments")
        .update({ content: editContent.trim() })
        .eq("id", comment.id)
        .eq("user_id", user!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      setEditing(false);
      queryClient.invalidateQueries({ queryKey: ["comments", postId] });
    },
    onError: () => toast({ title: "Error", description: "Could not update comment.", variant: "destructive" }),
  });

  const deleteComment = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("comments")
        .delete()
        .eq("id", comment.id)
        .eq("user_id", user!.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["comments", postId] });
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      queryClient.invalidateQueries({ queryKey: ["post", postId] });
    },
    onError: () => toast({ title: "Error", description: "Could not delete comment.", variant: "destructive" }),
  });

  return (
    <div className={`${depth > 0 ? "ml-6 border-l-2 border-muted pl-4" : ""}`}>
      <div className="py-3 space-y-2">
        <div className="flex items-center gap-2 text-sm">
          <Avatar className="h-6 w-6">
            <AvatarImage src={comment.profiles?.avatar_url ?? undefined} />
            <AvatarFallback className="text-[10px] bg-accent text-accent-foreground">
              {initials}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium">{comment.profiles?.display_name ?? "Anonymous"}</span>
          <span className="text-muted-foreground">·</span>
          <span className="text-muted-foreground">
            {formatDistanceToNow(new Date(comment.created_at), { addSuffix: true })}
          </span>
        </div>

        {editing ? (
          <div className="space-y-2">
            <Textarea
              value={editContent}
              onChange={(e) => setEditContent(e.target.value)}
              className="min-h-[60px] text-sm"
              maxLength={2000}
            />
            <div className="flex gap-2">
              <Button size="sm" onClick={() => updateComment.mutate()} disabled={updateComment.isPending}>
                Save
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <p className="text-sm leading-relaxed">{comment.content}</p>
        )}

        <div className="flex items-center gap-2">
          {user && depth < 3 && (
            <Button
              variant="ghost"
              size="sm"
              className="text-xs text-muted-foreground h-7 px-2"
              onClick={() => setReplying(!replying)}
            >
              <Reply className="h-3 w-3 mr-1" />
              Reply
            </Button>
          )}
          {isOwner && (
            <>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-muted-foreground h-7 px-2"
                onClick={() => setEditing(true)}
              >
                <Edit2 className="h-3 w-3 mr-1" />
                Edit
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-xs text-destructive h-7 px-2"
                onClick={() => deleteComment.mutate()}
              >
                <Trash2 className="h-3 w-3 mr-1" />
                Delete
              </Button>
            </>
          )}
        </div>

        {replying && (
          <div className="space-y-2 mt-2">
            <Textarea
              value={replyContent}
              onChange={(e) => setReplyContent(e.target.value)}
              placeholder="Write a reply..."
              className="min-h-[60px] text-sm"
              maxLength={2000}
            />
            <div className="flex gap-2">
              <Button size="sm" onClick={() => addReply.mutate()} disabled={addReply.isPending}>
                {addReply.isPending && <Loader2 className="h-3 w-3 animate-spin mr-1" />}
                Reply
              </Button>
              <Button size="sm" variant="ghost" onClick={() => setReplying(false)}>
                Cancel
              </Button>
            </div>
          </div>
        )}
      </div>

      {comment.replies?.map((reply) => (
        <CommentItem key={reply.id} comment={reply} postId={postId} depth={depth + 1} />
      ))}
    </div>
  );
}

export function CommentSection({ postId }: { postId: string }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newComment, setNewComment] = useState("");

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ["comments", postId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("comments")
        .select(`
          id, content, created_at, user_id, parent_id,
          profiles!comments_user_id_fkey ( display_name, avatar_url, user_id )
        `)
        .eq("post_id", postId)
        .order("created_at", { ascending: true });

      if (error) throw error;

      // Build tree
      const commentMap = new Map<string, CommentData>();
      const rootComments: CommentData[] = [];

      (data || []).forEach((c: any) => {
        const comment: CommentData = { ...c, profiles: c.profiles, replies: [] };
        commentMap.set(c.id, comment);
      });

      commentMap.forEach((comment) => {
        if (comment.parent_id && commentMap.has(comment.parent_id)) {
          commentMap.get(comment.parent_id)!.replies!.push(comment);
        } else {
          rootComments.push(comment);
        }
      });

      return rootComments;
    },
  });

  const addComment = useMutation({
    mutationFn: async () => {
      if (!user || !newComment.trim()) return;
      const { error } = await supabase.from("comments").insert({
        post_id: postId,
        user_id: user.id,
        content: newComment.trim(),
      });
      if (error) throw error;
    },
    onSuccess: () => {
      setNewComment("");
      queryClient.invalidateQueries({ queryKey: ["comments", postId] });
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      queryClient.invalidateQueries({ queryKey: ["post", postId] });
    },
    onError: () => toast({ title: "Error", description: "Could not add comment.", variant: "destructive" }),
  });

  return (
    <section className="space-y-6">
      <h3 className="text-lg font-serif font-semibold flex items-center gap-2">
        <MessageCircle className="h-5 w-5" />
        Comments
      </h3>

      {user ? (
        <div className="space-y-3">
          <Textarea
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            placeholder="What are your thoughts?"
            className="min-h-[80px]"
            maxLength={2000}
          />
          <Button
            onClick={() => addComment.mutate()}
            disabled={addComment.isPending || !newComment.trim()}
            size="sm"
            className="bg-accent text-accent-foreground hover:bg-accent/90"
          >
            {addComment.isPending && <Loader2 className="h-4 w-4 animate-spin mr-1" />}
            Post comment
          </Button>
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          Sign in to join the discussion.
        </p>
      )}

      {isLoading ? (
        <div className="py-4 text-center text-muted-foreground">Loading comments...</div>
      ) : comments.length > 0 ? (
        <div className="divide-y">
          {comments.map((comment) => (
            <CommentItem key={comment.id} comment={comment} postId={postId} />
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground py-4">No comments yet. Start the conversation!</p>
      )}
    </section>
  );
}
