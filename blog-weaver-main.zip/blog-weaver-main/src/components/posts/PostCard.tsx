import { Link } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Heart, MessageCircle, Bookmark } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface PostCardProps {
  id: string;
  title: string;
  excerpt: string | null;
  coverImageUrl: string | null;
  authorName: string;
  authorAvatar: string | null;
  authorId: string;
  publishedAt: string | null;
  readTimeMinutes: number | null;
  tags: string[] | null;
  likeCount: number;
  commentCount: number;
  isBookmarked?: boolean;
  onBookmark?: () => void;
}

export function PostCard({
  id,
  title,
  excerpt,
  coverImageUrl,
  authorName,
  authorAvatar,
  authorId,
  publishedAt,
  readTimeMinutes,
  tags,
  likeCount,
  commentCount,
  isBookmarked,
  onBookmark,
}: PostCardProps) {
  const initials = authorName.slice(0, 2).toUpperCase();
  const timeAgo = publishedAt
    ? formatDistanceToNow(new Date(publishedAt), { addSuffix: true })
    : "";

  return (
    <article className="group animate-fade-in">
      <div className="flex gap-6 py-6 border-b">
        <div className="flex-1 min-w-0 space-y-2">
          <div className="flex items-center gap-2 text-sm">
            <Link to={`/profile/${authorId}`} className="flex items-center gap-2 hover:underline">
              <Avatar className="h-5 w-5">
                <AvatarImage src={authorAvatar ?? undefined} />
                <AvatarFallback className="text-[10px] bg-accent text-accent-foreground">
                  {initials}
                </AvatarFallback>
              </Avatar>
              <span className="font-medium text-foreground">{authorName}</span>
            </Link>
            {timeAgo && (
              <>
                <span className="text-muted-foreground">·</span>
                <span className="text-muted-foreground">{timeAgo}</span>
              </>
            )}
          </div>

          <Link to={`/post/${id}`} className="block space-y-1">
            <h2 className="text-xl font-serif font-bold leading-tight group-hover:text-accent transition-colors line-clamp-2">
              {title}
            </h2>
            {excerpt && (
              <p className="text-muted-foreground line-clamp-2 text-sm leading-relaxed">
                {excerpt}
              </p>
            )}
          </Link>

          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              {readTimeMinutes && (
                <span>{readTimeMinutes} min read</span>
              )}
              {tags && tags.length > 0 && (
                <Link to={`/?tag=${encodeURIComponent(tags[0])}`}>
                  <Badge variant="secondary" className="text-xs font-normal">
                    {tags[0]}
                  </Badge>
                </Link>
              )}
            </div>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                <Heart className="h-4 w-4" />
                {likeCount}
              </span>
              <span className="flex items-center gap-1">
                <MessageCircle className="h-4 w-4" />
                {commentCount}
              </span>
              {onBookmark && (
                <button onClick={onBookmark} className="hover:text-accent transition-colors">
                  <Bookmark className={`h-4 w-4 ${isBookmarked ? "fill-accent text-accent" : ""}`} />
                </button>
              )}
            </div>
          </div>
        </div>

        {coverImageUrl && (
          <Link to={`/post/${id}`} className="hidden sm:block flex-shrink-0">
            <img
              src={coverImageUrl}
              alt={title}
              className="w-28 h-28 object-cover rounded"
              loading="lazy"
            />
          </Link>
        )}
      </div>
    </article>
  );
}
