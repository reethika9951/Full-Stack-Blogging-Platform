import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UsePostsOptions {
  search?: string;
  tag?: string;
  sort?: "newest" | "likes" | "comments";
  authorId?: string;
  status?: "published" | "draft";
}

export interface PostWithMeta {
  id: string;
  title: string;
  excerpt: string | null;
  cover_image_url: string | null;
  status: "draft" | "published";
  tags: string[] | null;
  read_time_minutes: number | null;
  published_at: string | null;
  created_at: string;
  author_id: string;
  content: string;
  author: {
    user_id: string;
    display_name: string;
    avatar_url: string | null;
  } | null;
  like_count: number;
  comment_count: number;
}

export function usePosts(options: UsePostsOptions = {}) {
  const { search, tag, sort = "newest", authorId, status = "published" } = options;

  return useQuery({
    queryKey: ["posts", { search, tag, sort, authorId, status }],
    queryFn: async (): Promise<PostWithMeta[]> => {
      let query = supabase
        .from("posts")
        .select(`
          *,
          profiles!posts_author_id_fkey ( user_id, display_name, avatar_url ),
          likes ( id ),
          comments ( id )
        `)
        .eq("status", status);

      if (authorId) {
        query = query.eq("author_id", authorId);
      }

      if (search) {
        query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`);
      }

      if (tag) {
        query = query.contains("tags", [tag]);
      }

      if (sort === "newest") {
        query = query.order("published_at", { ascending: false, nullsFirst: false });
      } else {
        query = query.order("created_at", { ascending: false });
      }

      const { data, error } = await query;

      if (error) throw error;

      const posts = (data || []).map((post: any) => ({
        id: post.id,
        title: post.title,
        excerpt: post.excerpt,
        cover_image_url: post.cover_image_url,
        status: post.status,
        tags: post.tags,
        read_time_minutes: post.read_time_minutes,
        published_at: post.published_at,
        created_at: post.created_at,
        author_id: post.author_id,
        content: post.content,
        author: post.profiles,
        like_count: post.likes?.length ?? 0,
        comment_count: post.comments?.length ?? 0,
      }));

      if (sort === "likes") {
        posts.sort((a: PostWithMeta, b: PostWithMeta) => b.like_count - a.like_count);
      } else if (sort === "comments") {
        posts.sort((a: PostWithMeta, b: PostWithMeta) => b.comment_count - a.comment_count);
      }

      return posts;
    },
  });
}

export function usePost(postId: string | undefined) {
  return useQuery({
    queryKey: ["post", postId],
    enabled: !!postId,
    queryFn: async (): Promise<PostWithMeta | null> => {
      const { data, error } = await supabase
        .from("posts")
        .select(`
          *,
          profiles!posts_author_id_fkey ( user_id, display_name, avatar_url ),
          likes ( id ),
          comments ( id )
        `)
        .eq("id", postId!)
        .single();

      if (error) throw error;
      if (!data) return null;

      return {
        id: data.id,
        title: data.title,
        excerpt: data.excerpt,
        cover_image_url: data.cover_image_url,
        status: data.status,
        tags: data.tags,
        read_time_minutes: data.read_time_minutes,
        published_at: data.published_at,
        created_at: data.created_at,
        author_id: data.author_id,
        content: data.content,
        author: data.profiles as any,
        like_count: (data.likes as any)?.length ?? 0,
        comment_count: (data.comments as any)?.length ?? 0,
      };
    },
  });
}

export function useMyDrafts() {
  return useQuery({
    queryKey: ["my-drafts"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return [];

      const { data, error } = await supabase
        .from("posts")
        .select("id, title, excerpt, updated_at, status")
        .eq("author_id", user.id)
        .eq("status", "draft")
        .order("updated_at", { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });
}
