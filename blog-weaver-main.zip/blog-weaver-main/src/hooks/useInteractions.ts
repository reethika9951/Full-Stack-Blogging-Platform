import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

export function useLike(postId: string) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: isLiked = false } = useQuery({
    queryKey: ["like", postId, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("likes")
        .select("id")
        .eq("post_id", postId)
        .eq("user_id", user!.id)
        .maybeSingle();
      return !!data;
    },
  });

  const toggleLike = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Must be logged in");

      if (isLiked) {
        await supabase
          .from("likes")
          .delete()
          .eq("post_id", postId)
          .eq("user_id", user.id);
      } else {
        await supabase
          .from("likes")
          .insert({ post_id: postId, user_id: user.id });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["like", postId] });
      queryClient.invalidateQueries({ queryKey: ["posts"] });
      queryClient.invalidateQueries({ queryKey: ["post", postId] });
    },
    onError: () => {
      toast({ title: "Error", description: "Could not update like.", variant: "destructive" });
    },
  });

  return { isLiked, toggleLike: toggleLike.mutate };
}

export function useBookmark(postId: string) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: isBookmarked = false } = useQuery({
    queryKey: ["bookmark", postId, user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("bookmarks")
        .select("id")
        .eq("post_id", postId)
        .eq("user_id", user!.id)
        .maybeSingle();
      return !!data;
    },
  });

  const toggleBookmark = useMutation({
    mutationFn: async () => {
      if (!user) throw new Error("Must be logged in");

      if (isBookmarked) {
        await supabase
          .from("bookmarks")
          .delete()
          .eq("post_id", postId)
          .eq("user_id", user.id);
      } else {
        await supabase
          .from("bookmarks")
          .insert({ post_id: postId, user_id: user.id });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bookmark", postId] });
      queryClient.invalidateQueries({ queryKey: ["bookmarks"] });
      toast({
        title: isBookmarked ? "Removed from bookmarks" : "Saved to bookmarks",
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Could not update bookmark.", variant: "destructive" });
    },
  });

  return { isBookmarked, toggleBookmark: toggleBookmark.mutate };
}

export function useBookmarkedPosts() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["bookmarks", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookmarks")
        .select(`
          post_id,
          posts (
            *,
            profiles!posts_author_id_fkey ( user_id, display_name, avatar_url ),
            likes ( id ),
            comments ( id )
          )
        `)
        .eq("user_id", user!.id)
        .order("created_at", { ascending: false });

      if (error) throw error;

      return (data || []).map((b: any) => ({
        id: b.posts.id,
        title: b.posts.title,
        excerpt: b.posts.excerpt,
        cover_image_url: b.posts.cover_image_url,
        status: b.posts.status,
        tags: b.posts.tags,
        read_time_minutes: b.posts.read_time_minutes,
        published_at: b.posts.published_at,
        created_at: b.posts.created_at,
        author_id: b.posts.author_id,
        content: b.posts.content,
        author: b.posts.profiles,
        like_count: b.posts.likes?.length ?? 0,
        comment_count: b.posts.comments?.length ?? 0,
      }));
    },
  });
}
